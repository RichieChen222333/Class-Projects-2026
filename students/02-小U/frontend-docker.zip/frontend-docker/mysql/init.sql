CREATE TABLE students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50),
  skill VARCHAR(50)
);

INSERT INTO students (name, skill) VALUES
('小明', 'HTML'),
('小美', 'CSS'),
('阿強', 'JavaScript');
